"use strict";

require("dotenv").config();

const { Client, GatewayIntentBits, Events, EmbedBuilder } = require("discord.js");
const { calculateShot } = require("./engine/calculator");
const commands = require("./commands");

if (!process.env.DISCORD_TOKEN) {
  console.error("Missing DISCORD_TOKEN. Copy .env.example to .env and configure it.");
  process.exit(1);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once(Events.ClientReady, readyClient => {
  console.log(`E DOBBIN online as ${readyClient.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  try {
    if (interaction.commandName === "help") {
      return interaction.reply({
        ephemeral: true,
        embeds: [new EmbedBuilder()
          .setColor(0xB3132B)
          .setTitle("E DOBBIN — COMMANDS")
          .setDescription([
            "`/shot` — Calculate shot geometry",
            "`/practice` — Get a practice exercise",
            "`/help` — Show this menu",
            "",
            "Results are geometry estimates, not guaranteed pocketing predictions."
          ].join("\\n"))]
      });
    }

    if (interaction.commandName === "practice") {
      const exercises = [
        "Place an object ball at (500, 500) and choose a corner pocket. Work out the ghost-ball contact point.",
        "Try a straight-line shot: cue (200, 500), object (500, 500), pocket (800, 500).",
        "Compare a centre-pocket route with a corner-pocket route and note how the cut angle changes."
      ];
      const pick = exercises[Math.floor(Math.random() * exercises.length)];
      return interaction.reply({ content: `**PRACTICE CHALLENGE**\\n${pick}`, ephemeral: true });
    }

    if (interaction.commandName === "shot") {
      await interaction.deferReply({ ephemeral: true });
      const get = name => interaction.options.getInteger(name, true);
      const result = calculateShot({
        cue: { x: get("cue_x"), y: get("cue_y") },
        object: { x: get("object_x"), y: get("object_y") },
        pocket: { x: get("pocket_x"), y: get("pocket_y") }
      });

      const embed = new EmbedBuilder()
        .setColor(0xB3132B)
        .setTitle("E DOBBIN — SHOT REPORT")
        .addFields(
          { name: "Shot classification", value: result.shotType, inline: true },
          { name: "Cut angle", value: `${result.cutAngle}°`, inline: true },
          { name: "Cue travel", value: `${result.cueDistance} units`, inline: true },
          { name: "Object travel", value: `${result.objectDistance} units`, inline: true },
          { name: "Ghost-ball position", value: `X: ${result.ghost.x.toFixed(2)}\\nY: ${result.ghost.y.toFixed(2)}`, inline: true }
        )
        .setFooter({ text: "Idealised geometry only • Spin, cushions and collision physics are not modelled" });

      return interaction.editReply({ embeds: [embed] });
    }
  } catch (error) {
    console.error(`Command ${interaction.commandName} failed:`, error);
    const message = error instanceof RangeError || error instanceof TypeError
      ? `Invalid shot input: ${error.message}`
      : "An unexpected error occurred. Please try again.";

    if (interaction.deferred || interaction.replied) {
      await interaction.editReply({ content: message });
    } else {
      await interaction.reply({ content: message, ephemeral: true });
    }
  }
});

client.login(process.env.DISCORD_TOKEN);
