"use strict";

const TABLE_SIZE = 1000;

function assertPoint(point, name) {
  if (!point || !Number.isFinite(point.x) || !Number.isFinite(point.y)) {
    throw new TypeError(`${name} must contain finite x and y coordinates.`);
  }
  if (point.x < 0 || point.x > TABLE_SIZE || point.y < 0 || point.y > TABLE_SIZE) {
    throw new RangeError(`${name} coordinates must be between 0 and ${TABLE_SIZE}.`);
  }
}

function distance(a, b) {
  return Math.hypot(b.x - a.x, b.y - a.y);
}

function normalize(vector) {
  const length = Math.hypot(vector.x, vector.y);
  if (length < 1e-9) throw new RangeError("Two positions must not be identical.");
  return { x: vector.x / length, y: vector.y / length };
}

function calculateShot({ cue, object, pocket, ballDiameter = 26 }) {
  assertPoint(cue, "Cue ball");
  assertPoint(object, "Object ball");
  assertPoint(pocket, "Pocket");

  if (!Number.isFinite(ballDiameter) || ballDiameter <= 0 || ballDiameter > 100) {
    throw new RangeError("Ball diameter must be greater than 0 and no more than 100.");
  }

  const objectToPocket = normalize({
    x: pocket.x - object.x,
    y: pocket.y - object.y
  });

  const ghost = {
    x: object.x - objectToPocket.x * ballDiameter,
    y: object.y - objectToPocket.y * ballDiameter
  };

  if (ghost.x < 0 || ghost.x > TABLE_SIZE || ghost.y < 0 || ghost.y > TABLE_SIZE) {
    throw new RangeError("Calculated contact position falls outside the table.");
  }

  const cueDirection = normalize({ x: ghost.x - cue.x, y: ghost.y - cue.y });
  const cosine = Math.max(-1, Math.min(1,
    cueDirection.x * objectToPocket.x + cueDirection.y * objectToPocket.y
  ));
  const cutAngle = Math.acos(cosine) * 180 / Math.PI;

  const shotType = cutAngle <= 5 ? "Straight"
    : cutAngle <= 20 ? "Slight cut"
    : cutAngle <= 40 ? "Medium cut"
    : cutAngle <= 60 ? "Thin cut" : "Very thin cut";

  return {
    ghost,
    cutAngle: Number(cutAngle.toFixed(2)),
    cueDistance: Number(distance(cue, ghost).toFixed(2)),
    objectDistance: Number(distance(object, pocket).toFixed(2)),
    shotType
  };
}

module.exports = { calculateShot, TABLE_SIZE };
