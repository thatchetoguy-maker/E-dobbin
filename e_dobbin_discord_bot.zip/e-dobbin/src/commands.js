"use strict";

const { SlashCommandBuilder } = require("discord.js");

const commands = [
  new SlashCommandBuilder()
    .setName("shot")
    .setDescription("Calculate basic shot geometry from table coordinates")
    .addIntegerOption(o => o.setName("cue_x").setDescription("Cue ball X (0–1000)").setMinValue(0).setMaxValue(1000).setRequired(true))
    .addIntegerOption(o => o.setName("cue_y").setDescription("Cue ball Y (0–1000)").setMinValue(0).setMaxValue(1000).setRequired(true))
    .addIntegerOption(o => o.setName("object_x").setDescription("Object ball X (0–1000)").setMinValue(0).setMaxValue(1000).setRequired(true))
    .addIntegerOption(o => o.setName("object_y").setDescription("Object ball Y (0–1000)").setMinValue(0).setMaxValue(1000).setRequired(true))
    .addIntegerOption(o => o.setName("pocket_x").setDescription("Target pocket X (0–1000)").setMinValue(0).setMaxValue(1000).setRequired(true))
    .addIntegerOption(o => o.setName("pocket_y").setDescription("Target pocket Y (0–1000)").setMinValue(0).setMaxValue(1000).setRequired(true)),
  new SlashCommandBuilder().setName("help").setDescription("Show E Dobbin commands"),
  new SlashCommandBuilder().setName("practice").setDescription("Get a geometry practice exercise")
];

module.exports = commands;
