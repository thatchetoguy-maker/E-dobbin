"use strict";

require("dotenv").config();

const { REST, Routes } = require("discord.js");
const commands = require("../src/commands");

async function main() {
  const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;
  if (!DISCORD_TOKEN || !CLIENT_ID || !GUILD_ID) {
    throw new Error("DISCORD_TOKEN, CLIENT_ID and GUILD_ID must be set in .env.");
  }

  const rest = new REST({ version: "10" }).setToken(DISCORD_TOKEN);
  await rest.put(
    Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
    { body: commands.map(command => command.toJSON()) }
  );
  console.log(`Registered ${commands.length} commands in guild ${GUILD_ID}.`);
}

main().catch(error => {
  console.error("Command deployment failed:", error);
  process.exitCode = 1;
});
