# E Dobbin — Discord Shot Analysis Bot

A Discord-only educational 8-ball-pool geometry assistant. It calculates an idealised ghost-ball contact point, cut angle and travel distances from coordinates supplied by a user.

## Requirements
- Node.js 22+
- A Discord application and bot
- A test Discord server

## Setup
1. Install Node.js 22 or newer.
2. Extract this project and run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add your Discord bot token, application/client ID and test server ID.
5. In the Discord Developer Portal, enable the bot and use the `bot` and `applications.commands` OAuth scopes.
6. Run `npm run deploy`.
7. Run `npm start`.

## Commands
- `/shot` — calculate an idealised shot geometry estimate.
- `/practice` — receive a practice challenge.
- `/help` — display command information.

## Tests
Run `npm test`.

## Coordinate model
The table is represented as a 1000 × 1000 coordinate plane. The default ball diameter is 26 units. This is a simplified geometric model; it does not simulate spin, throw, cushion response, ball collisions, pocket jaws, or game-specific physics. It does not connect to or automate 8 Ball Pool.

## Security
- Keep `.env` private and never commit bot tokens.
- If a token is exposed, regenerate it in the Discord Developer Portal.
- Use a dedicated test server before inviting the bot elsewhere.
