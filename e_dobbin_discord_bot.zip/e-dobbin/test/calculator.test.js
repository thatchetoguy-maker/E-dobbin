"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { calculateShot } = require("../src/engine/calculator");

test("calculates a straight shot ghost-ball position", () => {
  const result = calculateShot({
    cue: { x: 200, y: 500 },
    object: { x: 500, y: 500 },
    pocket: { x: 800, y: 500 }
  });
  assert.equal(result.ghost.x, 474);
  assert.equal(result.ghost.y, 500);
  assert.equal(result.cutAngle, 0);
  assert.equal(result.shotType, "Straight");
});

test("rejects coordinates outside the table", () => {
  assert.throws(() => calculateShot({
    cue: { x: -1, y: 0 },
    object: { x: 500, y: 500 },
    pocket: { x: 800, y: 500 }
  }), /between 0 and 1000/);
});
